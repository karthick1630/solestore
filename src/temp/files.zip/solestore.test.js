/**
 * ═══════════════════════════════════════════════════════════════
 *  SoleStore — Automation Test Suite  (zero-dependency Node.js)
 * ═══════════════════════════════════════════════════════════════
 */

let passed = 0, failed = 0, suites = 0;
const results = [];

function describe(label, fn) {
  suites++;
  results.push({ type: "suite", label });
  fn();
}

function it(label, fn) {
  try {
    fn();
    passed++;
    results.push({ type: "pass", label });
  } catch (e) {
    failed++;
    results.push({ type: "fail", label, msg: e.message });
  }
}

const expect = (val) => ({
  toBe:             (exp) => { if (val !== exp)            throw new Error(`Expected ${JSON.stringify(exp)}, got ${JSON.stringify(val)}`); },
  toEqual:          (exp) => { if (JSON.stringify(val) !== JSON.stringify(exp)) throw new Error(`Expected ${JSON.stringify(exp)}, got ${JSON.stringify(val)}`); },
  toHaveLength:     (n)   => { if (val.length !== n)      throw new Error(`Expected length ${n}, got ${val.length}`); },
  toBeGreaterThan:  (n)   => { if (!(val > n))            throw new Error(`Expected ${val} > ${n}`); },
  toBeLessThan:     (n)   => { if (!(val < n))            throw new Error(`Expected ${val} < ${n}`); },
  toBeGreaterThanOrEqualTo: (n) => { if (!(val >= n))     throw new Error(`Expected ${val} >= ${n}`); },
  toBeLessThanOrEqualTo:    (n) => { if (!(val <= n))     throw new Error(`Expected ${val} <= ${n}`); },
  toMatch:          (re)  => { if (!re.test(val))         throw new Error(`Expected "${val}" to match ${re}`); },
  toContain:        (x)   => { if (!val.includes(x))      throw new Error(`Expected array to contain ${JSON.stringify(x)}`); },
  toBeGreaterThanOrEqualTo: (n) => { if (!(val >= n)) throw new Error(`Expected ${val} >= ${n}`); },
});

// ── SoleStore core logic (copy of SoleStore.jsx internals) ───────

const rupee = n => `₹${Number(n).toLocaleString("en-IN")}`;
const off   = (mrp, price) => Math.round(((mrp - price) / mrp) * 100);
const calcDiscount = (coupon, sub) => {
  if (!coupon?.active || sub < coupon.minOrder) return 0;
  return coupon.type === "percent" ? Math.round(sub * coupon.value / 100) : coupon.value;
};
const getShipping  = (subtotalAfterDiscount) => subtotalAfterDiscount >= 3000 ? 0 : 99;
const cartTotal    = (cart) => cart.reduce((s, i) => s + i.price * i.qty, 0);
const cartQtyFn    = (cart) => cart.reduce((s, i) => s + i.qty, 0);
const toggleWish   = (wishlist, id) => wishlist.includes(id) ? wishlist.filter(x => x !== id) : [...wishlist, id];
const addToCartFn  = (cart, item) => {
  const i = cart.findIndex(x => x.id === item.id && x.selSize === item.selSize && x.selColor === item.selColor);
  if (i >= 0) return cart.map((x, idx) => idx === i ? { ...x, qty: x.qty + (item.qty || 1) } : x);
  return [...cart, { ...item, qty: item.qty || 1 }];
};
const updQtyFn     = (cart, idx, q) => {
  if (q < 1) return cart.filter((_, i) => i !== idx);
  return cart.map((x, i) => i === idx ? { ...x, qty: q } : x);
};

// ── Seed data ────────────────────────────────────────────────────
const COUPONS = [
  { id:1, code:"SAVE10",  type:"percent", value:10,  minOrder:2000, active:true,  used:87  },
  { id:2, code:"SAVE15",  type:"percent", value:15,  minOrder:5000, active:true,  used:43  },
  { id:3, code:"FLAT500", type:"flat",    value:500, minOrder:3000, active:true,  used:126 },
  { id:4, code:"WELCOME", type:"flat",    value:200, minOrder:1000, active:true,  used:201 },
  { id:5, code:"SUMMER20",type:"percent", value:20,  minOrder:4000, active:false, used:312 },
];

const PRODUCTS = [
  { id:1,  name:"Air Phantom Pro",      brand:"Nike",         price:8999,  mrp:12999, cat:"sports",      sizes:[7,8,9,10,11],  colors:["Black","White","Red"],           stock:24, rating:4.8, reviews:312, badge:"BESTSELLER" },
  { id:2,  name:"Classic Oxford Elite", brand:"Clarks",       price:5499,  mrp:7499,  cat:"formal",      sizes:[7,8,9,10,11],  colors:["Black","Navy Blue"],             stock:16, rating:4.6, reviews:189, badge:null },
  { id:3,  name:"StreetWave Casual",    brand:"Adidas",       price:4299,  mrp:5999,  cat:"casual",      sizes:[6,7,8,9,10,11],colors:["White","Black","Sky Blue"],       stock:42, rating:4.7, reviews:478, badge:"NEW" },
  { id:4,  name:"Luna Blossom Pump",    brand:"Aldo",         price:3899,  mrp:5299,  cat:"women",       sizes:[4,5,6,7,8],    colors:["Rose Gold","Black","Cream"],      stock:28, rating:4.9, reviews:561, badge:"TOP RATED" },
  { id:5,  name:"TrailBlazer X9",       brand:"New Balance",  price:7299,  mrp:9999,  cat:"sports",      sizes:[7,8,9,10,11],  colors:["Forest Green","Black","Orange"],  stock:18, rating:4.7, reviews:203, badge:null },
  { id:6,  name:"Velvet Derby",         brand:"Louis Philippe",price:6999, mrp:9499,  cat:"formal",      sizes:[7,8,9,10,11],  colors:["Black","Navy Blue"],             stock:10, rating:4.5, reviews:94,  badge:"PREMIUM" },
  { id:7,  name:"Cork Slide Pro",       brand:"Birkenstock",  price:2999,  mrp:3999,  cat:"casual",      sizes:[6,7,8,9,10],   colors:["Cream","Black","Silver"],         stock:55, rating:4.3, reviews:723, badge:null },
  { id:8,  name:"Aura Chunky W",        brand:"Puma",         price:5499,  mrp:7499,  cat:"women",       sizes:[4,5,6,7,8,9],  colors:["White","Rose Gold","Black"],      stock:32, rating:4.8, reviews:417, badge:"TRENDING" },
  { id:9,  name:"Boost Elite Pro",      brand:"Adidas",       price:9499,  mrp:12999, cat:"sports",      sizes:[7,8,9,10,11],  colors:["White","Black","Orange"],         stock:19, rating:4.9, reviews:389, badge:"NEW" },
  { id:10, name:"Weekend Loafer",       brand:"Mochi",        price:2499,  mrp:3499,  cat:"casual",      sizes:[6,7,8,9,10,11],colors:["Navy Blue","Black","Cream"],      stock:38, rating:4.4, reviews:256, badge:null },
  { id:11, name:"Elegance Stiletto",    brand:"Steve Madden", price:4999,  mrp:6999,  cat:"women",       sizes:[4,5,6,7,8],    colors:["Black","Red","Silver"],           stock:21, rating:4.6, reviews:298, badge:null },
  { id:12, name:"Heritage Brogue",      brand:"Bata",         price:3799,  mrp:5299,  cat:"formal",      sizes:[7,8,9,10,11],  colors:["Black","Navy Blue"],             stock:22, rating:4.3, reviews:134, badge:null },
  { id:13, name:"Luxury Chrono Watch",  brand:"Titan",        price:4999,  mrp:7499,  cat:"accessories", sizes:[],             colors:["Silver","Black"],                 stock:30, rating:4.8, reviews:245, badge:"BESTSELLER" },
  { id:14, name:"Cuban Link Chain",     brand:"Malabar",      price:2999,  mrp:4499,  cat:"accessories", sizes:[],             colors:["Gold","Silver"],                  stock:45, rating:4.5, reviews:178, badge:"TRENDING" },
  { id:15, name:"Braided Leather Bracelet",brand:"Fossil",    price:1499,  mrp:2199,  cat:"accessories", sizes:[],             colors:["Black","Brown"],                  stock:60, rating:4.4, reviews:312, badge:null },
  { id:16, name:"Classic Leather Belt", brand:"Louis Philippe",price:1999, mrp:2999,  cat:"accessories", sizes:[],             colors:["Brown","Black"],                  stock:50, rating:4.6, reviews:198, badge:null },
  { id:17, name:"Premium Bifold Wallet",brand:"Tommy Hilfiger",price:2499, mrp:3499,  cat:"accessories", sizes:[],             colors:["Black","Brown"],                  stock:40, rating:4.7, reviews:423, badge:"NEW" },
  { id:18, name:"Aviator Sunglasses",   brand:"Ray-Ban",      price:3499,  mrp:5299,  cat:"accessories", sizes:[],             colors:["Gold","Silver","Black"],          stock:35, rating:4.9, reviews:567, badge:"TOP RATED" },
];

const ORDERS = [
  { id:"SS-2401", total:8999,  sub:8999,  disc:0,    ship:0,  status:"delivered",  payMethod:"UPI",  coupon:null,     items:1 },
  { id:"SS-2402", total:8458,  sub:9398,  disc:940,  ship:0,  status:"shipped",    payMethod:"Card", coupon:"SAVE10", items:2 },
  { id:"SS-2403", total:8999,  sub:9499,  disc:500,  ship:0,  status:"processing", payMethod:"UPI",  coupon:"FLAT500",items:1 },
  { id:"SS-2404", total:6999,  sub:6999,  disc:0,    ship:0,  status:"pending",    payMethod:"COD",  coupon:null,     items:1 },
  { id:"SS-2405", total:7308,  sub:8598,  disc:1290, ship:0,  status:"delivered",  payMethod:"UPI",  coupon:"SAVE15", items:1 },
];

// ═══════════════════════════════════════════════════════════════
//  1. UTILITY — rupee formatter
// ═══════════════════════════════════════════════════════════════
describe("💰 Utility — rupee formatter", () => {
  it("formats ₹8,999 correctly",              () => expect(rupee(8999)).toBe("₹8,999"));
  it("formats ₹1,00,000 in Indian system",    () => expect(rupee(100000)).toBe("₹1,00,000"));
  it("formats zero",                          () => expect(rupee(0)).toBe("₹0"));
  it("formats ₹12,999 correctly",             () => expect(rupee(12999)).toBe("₹12,999"));
  it("formats ₹1,50,000 correctly",           () => expect(rupee(150000)).toBe("₹1,50,000"));
  it("formats single digit ₹1",               () => expect(rupee(1)).toBe("₹1"));
  it("formats ₹99,99,999 correctly",          () => expect(rupee(9999999)).toBe("₹99,99,999"));
});

// ═══════════════════════════════════════════════════════════════
//  2. UTILITY — off() discount %
// ═══════════════════════════════════════════════════════════════
describe("📉 Utility — discount % (off)", () => {
  it("Air Phantom Pro = 31% off",            () => expect(off(12999, 8999)).toBe(31));
  it("Boost Elite Pro = 27% off",            () => expect(off(12999, 9499)).toBe(27));
  it("Oxford Elite = 27% off",               () => expect(off(7499,  5499)).toBe(27));
  it("TrailBlazer X9 = 27% off",             () => expect(off(9999,  7299)).toBe(27));
  it("Velvet Derby = 26% off",               () => expect(off(9499,  6999)).toBe(26));
  it("returns 0 when price equals mrp",      () => expect(off(5000, 5000)).toBe(0));
  it("50% off scenario",                     () => expect(off(10000, 5000)).toBe(50));
  it("rounds correctly on non-even pct",     () => expect(off(3000, 2333)).toBe(22));
});

// ═══════════════════════════════════════════════════════════════
//  3. COUPON ENGINE — calcDiscount
// ═══════════════════════════════════════════════════════════════
describe("🏷️  Coupons — calcDiscount engine", () => {
  const [save10, save15, flat500, welcome, summer] = COUPONS;

  it("SAVE10: 10% on ₹5,000 = ₹500",                  () => expect(calcDiscount(save10, 5000)).toBe(500));
  it("SAVE15: 15% on ₹8,000 = ₹1,200",                () => expect(calcDiscount(save15, 8000)).toBe(1200));
  it("FLAT500: flat ₹500 on ₹4,000",                  () => expect(calcDiscount(flat500, 4000)).toBe(500));
  it("WELCOME: flat ₹200 on ₹1,500",                  () => expect(calcDiscount(welcome, 1500)).toBe(200));
  it("SAVE10: rejects sub below minOrder ₹2,000",      () => expect(calcDiscount(save10, 1999)).toBe(0));
  it("SAVE15: rejects sub below minOrder ₹5,000",      () => expect(calcDiscount(save15, 4999)).toBe(0));
  it("SUMMER20 is inactive → returns 0",               () => expect(calcDiscount(summer, 9999)).toBe(0));
  it("null coupon → 0",                                () => expect(calcDiscount(null, 5000)).toBe(0));
  it("undefined coupon → 0",                          () => expect(calcDiscount(undefined, 5000)).toBe(0));
  it("SAVE10: applies exactly at minOrder ₹2,000",     () => expect(calcDiscount(save10, 2000)).toBe(200));
  it("SAVE10: rounds correctly on ₹3,333",             () => expect(calcDiscount(save10, 3333)).toBe(333));
  it("FLAT500: value capped at flat, not percent",     () => expect(calcDiscount(flat500, 99999)).toBe(500));
});

// ═══════════════════════════════════════════════════════════════
//  4. SHIPPING LOGIC
// ═══════════════════════════════════════════════════════════════
describe("🚚 Shipping — free above ₹3,000", () => {
  it("₹0 subtotal → ₹99 shipping",          () => expect(getShipping(0)).toBe(99));
  it("₹2,999 → ₹99 shipping",               () => expect(getShipping(2999)).toBe(99));
  it("₹3,000 exactly → FREE",               () => expect(getShipping(3000)).toBe(0));
  it("₹3,001 → FREE",                       () => expect(getShipping(3001)).toBe(0));
  it("₹8,999 → FREE",                       () => expect(getShipping(8999)).toBe(0));
  it("₹1 → ₹99 shipping",                   () => expect(getShipping(1)).toBe(99));
});

// ═══════════════════════════════════════════════════════════════
//  5. CART — addToCart
// ═══════════════════════════════════════════════════════════════
describe("🛒 Cart — addToCart", () => {
  const p1 = { id:1, selSize:9,  selColor:"Black",    qty:1, price:8999, name:"Air Phantom Pro" };
  const p2 = { id:2, selSize:8,  selColor:"Navy Blue", qty:1, price:5499, name:"Oxford" };

  it("adds to empty cart",                         () => {
    const c = addToCartFn([], p1);
    expect(c).toHaveLength(1);
    expect(c[0].id).toBe(1);
  });

  it("adds second distinct product",               () => expect(addToCartFn([p1], p2)).toHaveLength(2));

  it("merges same id+size+color — increments qty", () => {
    const c = addToCartFn([p1], { ...p1, qty:1 });
    expect(c).toHaveLength(1);
    expect(c[0].qty).toBe(2);
  });

  it("same id + different size = separate line",   () => expect(addToCartFn([p1], { ...p1, selSize:10 })).toHaveLength(2));
  it("same id + different color = separate line",  () => expect(addToCartFn([p1], { ...p1, selColor:"White" })).toHaveLength(2));

  it("merges qty:2 addition → qty 3",              () => {
    const c = addToCartFn([p1], { ...p1, qty:2 });
    expect(c[0].qty).toBe(3);
  });

  it("defaults missing qty to 1",                  () => {
    const noQty = { id:3, selSize:7, selColor:"Black", price:4299, name:"StreetWave" };
    const c = addToCartFn([], noQty);
    expect(c[0].qty).toBe(1);
  });

  it("does not mutate original cart",              () => {
    const original = [{ ...p1 }];
    addToCartFn(original, p2);
    expect(original).toHaveLength(1);
  });
});

// ═══════════════════════════════════════════════════════════════
//  6. CART — updQty (stepper)
// ═══════════════════════════════════════════════════════════════
describe("🛒 Cart — updQty stepper", () => {
  const base = [
    { id:1, selSize:9, selColor:"Black",    qty:2, price:8999, name:"A" },
    { id:2, selSize:8, selColor:"Navy Blue",qty:1, price:5499, name:"B" },
  ];

  it("increases item[0] qty to 3",            () => expect(updQtyFn(base, 0, 3)[0].qty).toBe(3));
  it("decreases item[0] qty to 1",            () => expect(updQtyFn(base, 0, 1)[0].qty).toBe(1));
  it("removes item[0] when qty=0",            () => {
    const c = updQtyFn(base, 0, 0);
    expect(c).toHaveLength(1);
    expect(c[0].id).toBe(2);
  });
  it("removes item[1] when qty=0",            () => {
    const c = updQtyFn(base, 1, 0);
    expect(c).toHaveLength(1);
    expect(c[0].id).toBe(1);
  });
  it("removes item when qty < 0",             () => expect(updQtyFn(base, 0, -1)).toHaveLength(1));
  it("does not affect other items",           () => {
    const c = updQtyFn(base, 0, 5);
    expect(c[1].qty).toBe(1);
  });
  it("does not mutate original",              () => {
    updQtyFn(base, 0, 99);
    expect(base[0].qty).toBe(2);
  });
});

// ═══════════════════════════════════════════════════════════════
//  7. CART — totals & qty count
// ═══════════════════════════════════════════════════════════════
describe("🛒 Cart — totals", () => {
  it("single item × 1",                () => expect(cartTotal([{ id:1, selSize:9, selColor:"Black", qty:1, price:8999, name:"A" }])).toBe(8999));
  it("single item × 3",                () => expect(cartTotal([{ id:1, selSize:9, selColor:"Black", qty:3, price:4299, name:"A" }])).toBe(12897));
  it("two items summed",               () => {
    const cart = [
      { id:1, selSize:9, selColor:"Black",    qty:1, price:8999, name:"A" },
      { id:2, selSize:8, selColor:"Navy Blue",qty:2, price:5499, name:"B" },
    ];
    expect(cartTotal(cart)).toBe(8999 + 5499 * 2);
  });
  it("empty cart = 0",                 () => expect(cartTotal([])).toBe(0));
  it("cartQty counts all units",       () => {
    const cart = [
      { id:1, selSize:9, selColor:"Black", qty:2, price:8999, name:"A" },
      { id:2, selSize:8, selColor:"Black", qty:3, price:5499, name:"B" },
    ];
    expect(cartQtyFn(cart)).toBe(5);
  });
  it("cartQty empty cart = 0",         () => expect(cartQtyFn([])).toBe(0));
});

// ═══════════════════════════════════════════════════════════════
//  8. CHECKOUT — full pricing pipeline
// ═══════════════════════════════════════════════════════════════
describe("💳 Checkout — full order pricing pipeline", () => {
  it("Order SS-2401: no coupon, sub>3k → free ship", () => {
    const sub=8999, disc=calcDiscount(null,sub), ship=getShipping(sub-disc);
    expect(disc).toBe(0); expect(ship).toBe(0); expect(sub-disc+ship).toBe(8999);
  });

  it("Order SS-2402: SAVE10 (10%), free ship", () => {
    const sub=9398, disc=calcDiscount(COUPONS[0],sub), ship=getShipping(sub-disc);
    expect(disc).toBe(940); expect(ship).toBe(0); expect(sub-disc+ship).toBe(8458);
  });

  it("Order SS-2403: FLAT500, free ship", () => {
    const sub=9499, disc=calcDiscount(COUPONS[2],sub), ship=getShipping(sub-disc);
    expect(disc).toBe(500); expect(ship).toBe(0); expect(sub-disc+ship).toBe(8999);
  });

  it("Order SS-2404: no coupon, sub>3k → free ship", () => {
    const sub=6999, disc=calcDiscount(null,sub), ship=getShipping(sub-disc);
    expect(disc).toBe(0); expect(ship).toBe(0); expect(sub-disc+ship).toBe(6999);
  });

  it("Order SS-2405: SAVE15 (15%), free ship", () => {
    const sub=8598, disc=calcDiscount(COUPONS[1],sub), ship=getShipping(sub-disc);
    expect(disc).toBe(1290); expect(ship).toBe(0); expect(sub-disc+ship).toBe(7308);
  });

  it("WELCOME coupon on small order: ₹200 off + ₹99 ship", () => {
    const sub=1200, disc=calcDiscount(COUPONS[3],sub), ship=getShipping(sub-disc);
    expect(disc).toBe(200); expect(ship).toBe(99); expect(sub-disc+ship).toBe(1099);
  });

  it("multi-item cart with SAVE15", () => {
    const cart = [
      { id:1, selSize:9, selColor:"Black", qty:1, price:8999, name:"A" },
      { id:3, selSize:8, selColor:"White", qty:2, price:4299, name:"B" },
    ];
    const sub=cartTotal(cart); // 17597
    const disc=calcDiscount(COUPONS[1],sub);
    const ship=getShipping(sub-disc);
    expect(sub).toBe(17597);
    expect(disc).toBe(2640);
    expect(ship).toBe(0);
    expect(sub-disc+ship).toBe(14957);
  });
});

// ═══════════════════════════════════════════════════════════════
//  9. PRODUCT DATA INTEGRITY
// ═══════════════════════════════════════════════════════════════
describe("👟 Products — data integrity", () => {
  it("all 18 products exist",                    () => expect(PRODUCTS).toHaveLength(18));
  it("all IDs are unique",                       () => expect(new Set(PRODUCTS.map(p=>p.id)).size).toBe(18));
  it("all prices below mrp",                     () => PRODUCTS.forEach(p => expect(p.price).toBeLessThan(p.mrp)));
  it("all products have ≥1 color",               () => PRODUCTS.forEach(p => expect(p.colors.length).toBeGreaterThan(0)));
  it("all shoe categories have ≥1 size",         () => PRODUCTS.filter(p=>p.cat!=="accessories").forEach(p => expect(p.sizes.length).toBeGreaterThan(0)));
  it("accessories have empty sizes array",       () => PRODUCTS.filter(p=>p.cat==="accessories").forEach(p => expect(p.sizes).toHaveLength(0)));
  it("all stock > 0",                            () => PRODUCTS.forEach(p => expect(p.stock).toBeGreaterThan(0)));
  it("all ratings between 1–5",                  () => PRODUCTS.forEach(p => { expect(p.rating).toBeGreaterThan(0); expect(p.rating).toBeLessThan(6); }));
  it("all reviews > 0",                          () => PRODUCTS.forEach(p => expect(p.reviews).toBeGreaterThan(0)));
  it("all discount percentages 1–99%",           () => PRODUCTS.forEach(p => { const pct=off(p.mrp,p.price); expect(pct).toBeGreaterThan(0); expect(pct).toBeLessThan(100); }));
  it("categories are valid values",              () => {
    const valid = ["sports","formal","casual","women","accessories"];
    PRODUCTS.forEach(p => expect(valid).toContain(p.cat));
  });
  it("Air Phantom Pro = ₹8,999",                 () => expect(PRODUCTS[0].price).toBe(8999));
  it("Boost Elite Pro = ₹9,499",                 () => expect(PRODUCTS[8].price).toBe(9499));
});

// ═══════════════════════════════════════════════════════════════
//  10. WISHLIST TOGGLE
// ═══════════════════════════════════════════════════════════════
describe("❤️  Wishlist — toggle logic", () => {
  it("adds id to empty wishlist",                () => expect(toggleWish([], 1)).toEqual([1]));
  it("removes id that exists",                   () => expect(toggleWish([1,2], 1)).toEqual([2]));
  it("toggle on → off returns empty",            () => expect(toggleWish(toggleWish([],3),3)).toEqual([]));
  it("preserves other ids on remove",            () => expect(toggleWish([1,2,3],2)).toEqual([1,3]));
  it("adds multiple IDs",                        () => {
    let w = toggleWish(toggleWish(toggleWish([],1),2),3);
    expect(w).toHaveLength(3);
  });
  it("does not duplicate id",                    () => {
    const w = toggleWish(toggleWish([],5),5);
    expect(w.filter(x=>x===5)).toHaveLength(0);
  });
  it("does not mutate original array",           () => {
    const original = [1,2,3];
    toggleWish(original, 4);
    expect(original).toHaveLength(3);
  });
});

// ═══════════════════════════════════════════════════════════════
//  11. ORDER DATA VALIDATION
// ═══════════════════════════════════════════════════════════════
describe("📦 Orders — math & integrity", () => {
  it("all totals match sub − disc + ship",        () => ORDERS.forEach(o => expect(o.sub - o.disc + o.ship).toBe(o.total)));
  it("discounted orders have 0 shipping",         () => ORDERS.filter(o=>o.disc>0).forEach(o => expect(o.ship).toBe(0)));
  it("no-discount orders with sub<3000 have ₹99", () => ORDERS.filter(o=>o.disc===0 && o.sub<3000).forEach(o => expect(o.ship).toBe(99)));
  it("all IDs start with SS-",                    () => ORDERS.forEach(o => expect(o.id).toMatch(/^SS-/)));
  it("all statuses are valid",                    () => {
    const valid = ["pending","processing","shipped","delivered","cancelled"];
    ORDERS.forEach(o => expect(valid).toContain(o.status));
  });
  it("all totals are positive",                   () => ORDERS.forEach(o => expect(o.total).toBeGreaterThan(0)));
  it("SS-2401 total = ₹8,999",                    () => expect(rupee(ORDERS[0].total)).toBe("₹8,999"));
  it("SS-2402 total = ₹8,458",                    () => expect(rupee(ORDERS[1].total)).toBe("₹8,458"));
});

// ═══════════════════════════════════════════════════════════════
//  12. COUPON DATA INTEGRITY
// ═══════════════════════════════════════════════════════════════
describe("🏷️  Coupons — data integrity", () => {
  it("all codes are uppercase",                   () => COUPONS.forEach(c => expect(c.code).toBe(c.code.toUpperCase())));
  it("all minOrders are positive",                () => COUPONS.forEach(c => expect(c.minOrder).toBeGreaterThan(0)));
  it("percent coupons: 1–99 value",               () => COUPONS.filter(c=>c.type==="percent").forEach(c => { expect(c.value).toBeGreaterThan(0); expect(c.value).toBeLessThan(100); }));
  it("flat coupons: value > 0",                   () => COUPONS.filter(c=>c.type==="flat").forEach(c => expect(c.value).toBeGreaterThan(0)));
  it("exactly 4 active coupons",                  () => expect(COUPONS.filter(c=>c.active)).toHaveLength(4));
  it("SUMMER20 is the only inactive coupon",      () => {
    const inactive = COUPONS.filter(c=>!c.active);
    expect(inactive).toHaveLength(1);
    expect(inactive[0].code).toBe("SUMMER20");
  });
  it("all IDs are unique",                        () => expect(new Set(COUPONS.map(c=>c.id)).size).toBe(COUPONS.length));
  it("coupon types are only 'percent' or 'flat'", () => COUPONS.forEach(c => expect(["percent","flat"]).toContain(c.type)));
});

// ═══════════════════════════════════════════════════════════════
//  13. EDGE CASES & BOUNDARY CONDITIONS
// ═══════════════════════════════════════════════════════════════
describe("🔬 Edge cases", () => {
  it("shipping free at exactly ₹3,000",                () => expect(getShipping(3000)).toBe(0));
  it("shipping ₹99 at ₹2,999",                         () => expect(getShipping(2999)).toBe(99));
  it("coupon at exact minOrder applies",               () => expect(calcDiscount(COUPONS[0],2000)).toBe(200));
  it("coupon 1 below minOrder rejected",               () => expect(calcDiscount(COUPONS[0],1999)).toBe(0));
  it("empty cart total = 0",                           () => expect(cartTotal([])).toBe(0));
  it("100 items × qty 10 = total 100 units",           () => {
    const big = Array.from({length:10}, (_,i) => ({ id:i+1, selSize:8, selColor:"Black", qty:10, price:1000, name:`P${i}` }));
    expect(cartTotal(big)).toBe(100000);
    expect(cartQtyFn(big)).toBe(100);
  });
  it("adding then removing same item leaves empty cart",() => {
    const p = { id:1, selSize:9, selColor:"Black", qty:1, price:8999, name:"A" };
    let c = addToCartFn([], p);
    c = updQtyFn(c, 0, 0);
    expect(c).toHaveLength(0);
  });
  it("rupee handles 0",                                () => expect(rupee(0)).toBe("₹0"));
  it("off() 100% off = 100 (edge)",                    () => expect(off(100,0)).toBe(100));
  it("multiple inactive-coupon attempts all return 0", () => {
    expect(calcDiscount(COUPONS[4], 9999)).toBe(0);
    expect(calcDiscount(null,        5000)).toBe(0);
    expect(calcDiscount(undefined,   5000)).toBe(0);
  });
});

// ═══════════════════════════════════════════════════════════════
//  PRINT RESULTS
// ═══════════════════════════════════════════════════════════════
const PASS = "\x1b[32m✓\x1b[0m";
const FAIL = "\x1b[31m✗\x1b[0m";
const BOLD = "\x1b[1m";
const DIM  = "\x1b[2m";
const RST  = "\x1b[0m";

console.log(`\n${BOLD}═══════════════════════════════════════════════════════════${RST}`);
console.log(`${BOLD}  SoleStore — Automation Test Suite${RST}`);
console.log(`${BOLD}═══════════════════════════════════════════════════════════${RST}\n`);

let currentSuite = "";
for (const r of results) {
  if (r.type === "suite") {
    console.log(`\n  ${BOLD}${r.label}${RST}`);
    currentSuite = r.label;
  } else if (r.type === "pass") {
    console.log(`    ${PASS} ${DIM}${r.label}${RST}`);
  } else {
    console.log(`    ${FAIL} ${r.label}`);
    console.log(`       ${"\x1b[31m"}↳ ${r.msg}${RST}`);
  }
}

const total = passed + failed;
console.log(`\n${BOLD}═══════════════════════════════════════════════════════════${RST}`);
console.log(`  ${BOLD}Suites:${RST}  ${suites}`);
console.log(`  ${BOLD}Total:${RST}   ${total}`);
console.log(`  \x1b[32m${BOLD}Passed:${RST}\x1b[0m  ${passed}`);
if (failed > 0) {
  console.log(`  \x1b[31m${BOLD}Failed:${RST}\x1b[0m  ${failed}`);
} else {
  console.log(`  \x1b[32m${BOLD}Failed:${RST}\x1b[0m  0`);
}
console.log(`${BOLD}═══════════════════════════════════════════════════════════${RST}\n`);

if (failed > 0) process.exit(1);
